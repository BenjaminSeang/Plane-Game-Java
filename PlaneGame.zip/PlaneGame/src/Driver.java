
public class Driver {
	public static void main(String[] args)
	{
	
		GameFrame frame = new GameFrame();
		frame.launchFrame();
	}
}
