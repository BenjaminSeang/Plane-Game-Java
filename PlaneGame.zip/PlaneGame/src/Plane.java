import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;

public class Plane extends GameObject{
	
	boolean left,up,right,down;
	int speed;
	boolean life = true;

	@Override
	public void drawSelf(Graphics pen)
	{
		//if not collide with shells, draw it
		if(life)
		{
			pen.drawImage(img, (int)x, (int)y, null);
		
			//move
			if(left)
			{
				x-= speed;
			}
			if(right)
			{
				x+=speed;
			}
			if(up)
			{
				y-= speed;
			}
			if(down)
			{
				y+= speed;
			}
		}
		
	}
	
	public Plane(Image img, int x, int y)
	{
		this.img = img;
		this.x = x;
		this.y = y;
		this.speed = 5;
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
	}
	
	public void addDirection(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
		case 37:
			left = true;
			break;
		case 38:
			up = true;
			break;
		case 39:
			right = true;
			break;
		case 40:
			down = true;
			break;
			
		}
	}
	
	public void minusDirection(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
		case 37:
			left = false;
			break;
		case 38:
			up = false;
			break;
		case 39:
			right = false;
			break;
		case 40:
			down = false;
			break;
			
		}
	}
}
