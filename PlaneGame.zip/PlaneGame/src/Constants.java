/*
 * Store constants
 */
public class Constants {
	public static final int FRAME_WIDTH = 500;
	public static final int FRAME_HEIGHT = 500;
}
