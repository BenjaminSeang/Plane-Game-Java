import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Date;


public class GameFrame extends Frame {
	
	Image planeImage = GameUtil.getImage("images/plane.png");
	Image backgroundImage = GameUtil.getImage("images/bg.jpg");
	
	//draw plane at the initial position
	Plane plane = new Plane(planeImage, 250, 400);
	
	//Total 50 shells
	Shell[] shells = new Shell[50];
	
	//declare explosion object
	Explode explosion;
	
	//record play time
	Date startTime = new Date();
	//Date endTime;
	//int playTime;
	Timer timer = new Timer(startTime);
	
	public void launchFrame()
	{
		this.setTitle("PlaneGame");
		this.setVisible(true);
		this.setSize(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
		this.setLocation(1000, 300);
		
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		
		//start repaint thread
		new PaintThread().start();
		
		//add keyboard control
		addKeyListener(new KeyMonitor());
		
		//create shells
		for(int i = 0; i < shells.length; i++)
		{
			shells[i] = new Shell();
		}
		
		
	}
	
	@Override
	public void paint(Graphics pen)
	{
		pen.drawImage(backgroundImage, 0, 0, null);
		plane.drawSelf(pen);
		timer.drawSelf(pen);

		//draw shells
		for(int i = 0; i < shells.length; i++)
		{
			shells[i].drawSelf(pen);
			
			//check if shells collide with the plane
			boolean collision = shells[i].getRect().intersects(plane.getRect());
			if(collision)
			{
				//stop timer
				timer.life = false;
				
				//plane's dead
				plane.life = false;
				
				if(explosion == null)
				{
					//draw explosion at plane's position
					explosion = new Explode(plane.x, plane.y);
					//endTime = new Date();
					//playTime = (int)((endTime.getTime() - startTime.getTime())/1000);
				}
				
				explosion.drawSelf(pen);
				
				//pen.setColor(Color.yellow);
				//Font f = new Font("TimesRoman", Font.PLAIN, 20);
				//pen.setFont(f);
				//pen.drawString("Time: " + playTime + "s", 400, 50);
			}
		}
		
	}
	
	//repaint thread
	class PaintThread extends Thread
	{	
		@Override
		public void run()
		{
			while(true)
			{
				repaint();
				try {
					Thread.sleep(40);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	//offscreen buffer to avoid blinking
	private Image offScreenImage = null;
	public void update (Graphics g)
	{
		if(offScreenImage == null)
		{
			offScreenImage = this.createImage(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
		}
		Graphics gOff = offScreenImage.getGraphics();
		paint(gOff);
		g.drawImage(offScreenImage, 0, 0, null);
	}
	
	//keyboard control
	class KeyMonitor extends KeyAdapter
	{

		@Override
		public void keyPressed(KeyEvent e) {
			plane.addDirection(e);
		}

		@Override
		public void keyReleased(KeyEvent e) {
			plane.minusDirection(e);
		}
		
	}
	
}