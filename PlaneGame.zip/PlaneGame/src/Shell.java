import java.awt.Color;
import java.awt.Graphics;

public class Shell extends GameObject{

	double degree;
	
	public Shell()
	{
		x = 250;
		y = 100;
		width = 10;
		height = 10;
		speed = 3;
		
		//random degree between 0 - 2PI
		degree = Math.random()*Math.PI*2;
	}
	
	public void drawSelf(Graphics pen)
	{
		Color old = pen.getColor();
		pen.setColor(Color.red);
		
		pen.fillOval((int)x, (int)y, width, height);
		
		//shell's movement
		x += speed*Math.cos(degree);
		y += speed*Math.sin(degree);
		
		//reflect respecting to left or right boarder
		if(x < 0 || x > Constants.FRAME_WIDTH - width)
		{
		degree = Math.PI-degree;
				
		}
		
		//reflect respecting to top or bottom boarder
		if(y < 0 || y > Constants.FRAME_HEIGHT - height )
		{
			degree = - degree;			
		}
		
		pen.setColor(old);
	}
}
