import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.Date;

public class Timer {
	
	boolean life = true;
	int playTime;
	Date startTime;
	Date endTime;
	//Color old;
	Font f = new Font("TimesRoman", Font.PLAIN, 20);
	
	public Timer(Date startTime)
	{
		this.startTime = startTime;
	}
	
	public void drawSelf(Graphics pen)
	{
		Color oldColor = pen.getColor();
		Font oldFont = pen.getFont();
		pen.setColor(Color.YELLOW);
		pen.setFont(f);
		
		if(life)
		{
			endTime = new Date();
			playTime = ((int)(endTime.getTime() - startTime.getTime())/1000);
			pen.drawString("Time:" + playTime + "s", 400, 50);
		}
		else
		{
			pen.drawString("Time:" + playTime + "s", 400, 50);
		}
		
		pen.setColor(oldColor);
		pen.setFont(oldFont);
		
	}

}
